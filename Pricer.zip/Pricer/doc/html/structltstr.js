var structltstr =
[
    [ "operator()", "structltstr.html#a2304e89521f8964d65a63a57e9bf20dc", null ]
];