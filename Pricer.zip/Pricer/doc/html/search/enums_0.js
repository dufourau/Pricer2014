var searchData=
[
  ['t_5ftype',['T_type',['../parser_8h.html#a90856b8fb3f1a65845ffec1ec2884c0f',1,'parser.h']]]
];
