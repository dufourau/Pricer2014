var searchData=
[
  ['delta',['delta',['../classBS.html#a5c4c13efff4f6aa1b869c86c1377b10b',1,'BS']]]
];
